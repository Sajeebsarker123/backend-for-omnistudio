const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const { env } = require('process');

const app = express();
const PORT = process.env.PORT ||5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static folders
app.use('/', express.static(path.join(__dirname, '../public')));
app.use('/admin', express.static(path.join(__dirname, '../admin')));
app.use('/videos', express.static(path.join(__dirname, '../videos')));

// Paths
const dataFile = path.join(__dirname, 'data.json');
const logFile = path.join(__dirname, '../log.txt');
const serverLogFile = path.join(__dirname, '../server-logs.txt');
const requestLogFile = path.join(__dirname, '../request-log.txt');

// Ensure files exist
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify([]));
if (!fs.existsSync(logFile)) fs.writeFileSync(logFile, '');
if (!fs.existsSync(serverLogFile)) fs.writeFileSync(serverLogFile, '');
if (!fs.existsSync(requestLogFile)) fs.writeFileSync(requestLogFile, '');

// Serial counters
let serverLogCounter = 1;
let requestLogCounter = 1;

// Log functions
function addLog(entry) {
    const timestamp = new Date().toLocaleString('en-GB', { timeZone: 'Asia/Dhaka' });
    const logLine = `[${timestamp}] ${entry}\n`;
    fs.appendFileSync(logFile, logLine);
}

function addServerLog(entry) {
    const timestamp = new Date().toLocaleString('en-GB', { timeZone: 'Asia/Dhaka' });
    const logLine = `${serverLogCounter}. [${timestamp}] ${entry}\n`;
    fs.appendFileSync(serverLogFile, logLine);
    serverLogCounter++;
}

function addRequestLog(entry) {
    const timestamp = new Date().toLocaleString('en-GB', { timeZone: 'Asia/Dhaka' });
    const logLine = `${requestLogCounter}. [${timestamp}] ${entry}\n`;
    fs.appendFileSync(requestLogFile, logLine);
    requestLogCounter++;
}

// Middleware to log every request and response
app.use((req, res, next) => {
    const method = req.method;
    const url = req.originalUrl;
    const start = Date.now();

    addRequestLog(`REQUEST STARTED | Method: ${method} | Path: ${url}`);

    res.on('finish', () => {
        const duration = Date.now() - start;
        const status = res.statusCode;
        addRequestLog(`REQUEST COMPLETED | Method: ${method} | Path: ${url} | Status: ${status} | Duration: ${duration}ms`);
    });

    next();
});

// Multer setup for file upload
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../videos'));
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + file.originalname.replace(/ /g, '_');
        cb(null, uniqueName);
    }
});

const upload = multer({ storage });

// API: Get all items
app.get('/api/items', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(dataFile));
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: 'Failed to read data' });
    }
});

// API: New upload
app.post('/api/items', upload.single('file'), (req, res) => {
    const { title, description, category } = req.body;

    if (!req.file || !title || !description || !category) {
        addRequestLog(`UPLOAD FAILED | Missing data or file`);
        return res.status(400).json({ success: false, message: 'Missing data or file' });
    }

    let data = JSON.parse(fs.readFileSync(dataFile));

    const newItem = {
        id: Date.now(),
        title,
        description,
        filename: req.file.filename,
        category,
        uploadedAt: new Date().toISOString()
    };

    data.push(newItem);
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));

    addLog(`UPLOADED | Category: ${category} | File: ${req.file.filename} | Title: "${title}" | Description: ${description}`);
    addServerLog(`CONTENT UPLOADED | ID: ${newItem.id} | Category: ${category} | File: ${req.file.filename}`);

    res.json({ success: true, item: newItem });
});

// API: Update item (edit title & description)
app.post('/api/update', (req, res) => {
    const { id, title, description } = req.body;

    if (!id || !title || !description) {
        addRequestLog(`UPDATE FAILED | Missing data`);
        return res.status(400).json({ success: false, message: 'Missing data' });
    }

    let data = JSON.parse(fs.readFileSync(dataFile));
    const index = data.findIndex(item => item.id === parseInt(id));

    if (index === -1) {
        addRequestLog(`UPDATE FAILED | Item not found ID: ${id}`);
        return res.status(404).json({ success: false, message: 'Item not found' });
    }

    data[index].title = title;
    data[index].description = description;

    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));

    addLog(`UPDATED | ID: ${id} | New Title: "${title}" | New Description: ${description}`);
    addServerLog(`CONTENT UPDATED | ID: ${id} | New Title: "${title}"`);

    res.json({ success: true, item: data[index] });
});

// API: Delete item
app.delete('/api/items/:id', (req, res) => {
    const id = parseInt(req.params.id);

    let data = JSON.parse(fs.readFileSync(dataFile));
    const index = data.findIndex(item => item.id === id);

    if (index === -1) {
        addRequestLog(`DELETE FAILED | Item not found ID: ${id}`);
        return res.status(404).json({ success: false });
    }

    const item = data[index];
    const filePath = path.join(__dirname, '../videos', item.filename);

    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
    }

    data.splice(index, 1);
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));

    addLog(`DELETED | ID: ${id} | Category: ${item.category} | File: ${item.filename}`);
    addServerLog(`CONTENT DELETED | ID: ${id} | File: ${item.filename}`);

    res.json({ success: true });
});

// Server start
addServerLog('SERVER STARTED');

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`- Home: http://localhost:${PORT}`);
    console.log(`- Admin Upload: http://localhost:${PORT}/admin/admin1.html`);
    console.log(`- Server Logs: ${serverLogFile}`);
    console.log(`- Request Logs: ${requestLogFile}`);
});

// Server stop (Ctrl+C)
process.on('SIGINT', () => {
    addServerLog('SERVER STOPPED');
    console.log('\nServer stopped gracefully');
    process.exit(0);
});

process.on('SIGTERM', () => {
    addServerLog('SERVER STOPPED');
    process.exit(0);
});